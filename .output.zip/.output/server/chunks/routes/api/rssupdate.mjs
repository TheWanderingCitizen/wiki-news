import { d as defineEventHandler } from '../../runtime.mjs';
import { updateRssData } from './rssFetcher.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'axios';
import 'xml2js';
import 'node-cron';

const rssupdate = defineEventHandler(async (event) => {
  try {
    await updateRssData();
    return { success: true, message: "RSS data updated successfully." };
  } catch (error) {
    return { success: false, message: error.message };
  }
});

export { rssupdate as default };
//# sourceMappingURL=rssupdate.mjs.map
