import { d as defineEventHandler } from '../../runtime.mjs';
import { promises } from 'fs';
import { resolve } from 'path';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:url';

const rssget = defineEventHandler(async (event) => {
  const filePath = resolve("static/rssData.json");
  try {
    const data = await promises.readFile(filePath, "utf8");
    return JSON.parse(data);
  } catch (error) {
    return { error: "RSS data not found.", details: error.message };
  }
});

export { rssget as default };
//# sourceMappingURL=rssget.mjs.map
