import axios from 'axios';
import { parseStringPromise } from 'xml2js';
import { promises } from 'fs';
import { resolve } from 'path';
import cron from 'node-cron';

function extractPostId(link) {
  const match = link.match(/p\/(\d+)/);
  return match ? match[1] : null;
}
async function fetchPostDetails(postId) {
  const url = `https://rsshub.liumingye.cn/baidu/tieba/post/lz/${postId}`;
  try {
    const response = await axios.get(url);
    const detailedData = await parseStringPromise(response.data, { explicitArray: false });
    const cleanRegex = /【只看楼主】|作者：[^\s]+|楼层：\d+|楼主/g;
    if (detailedData.rss.channel.item) {
      if (detailedData.rss.channel.item.description) {
        detailedData.rss.channel.item.description = detailedData.rss.channel.item.description.replace(cleanRegex, "");
      }
      if (detailedData.rss.channel.title) {
        detailedData.rss.channel.title = detailedData.rss.channel.title.replace(cleanRegex, "");
      }
    }
    return detailedData;
  } catch (error) {
    console.error(`Failed to fetch details for post ID ${postId}:`, error);
    return null;
  }
}
async function updateRssData() {
  console.log("Fetching RSS data...");
  const rssUrl = "https://rsshub.liumingye.cn/baidu/tieba/user/%E7%81%AC%E7%81%ACG%E7%81%AC%E7%81%AC&";
  const filePath = resolve("static/rssData.json");
  try {
    const response = await axios.get(rssUrl);
    const rssData = response.data;
    const result = await parseStringPromise(rssData, { explicitArray: false });
    let items = result.rss.channel.item;
    items = Array.isArray(items) ? items : [items];
    const detailedItems = await Promise.all(items.map(async (item) => {
      const postId = extractPostId(item.link);
      if (postId) {
        return await fetchPostDetails(postId);
      }
      return item;
    }));
    await promises.writeFile(filePath, JSON.stringify(detailedItems, null, 2), "utf8");
    console.log("RSS data updated and saved to file successfully.");
  } catch (error) {
    console.error("Error:", error);
  }
}
cron.schedule("0 0 * * *", updateRssData);

export { updateRssData };
//# sourceMappingURL=rssFetcher.mjs.map
